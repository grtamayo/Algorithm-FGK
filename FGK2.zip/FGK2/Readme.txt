This archive contains *basic* implementations of the following algorithm:

Dynamic Huffman Coding - Algorithm FGK (fgkc.c and fgkd.c, zfgk.c);

Notes:

For personal, academic, and research purposes only. Freely distributable.

-- Gerald R. Tamayo, BSIE
   Philippines
