#if !defined(U_TYPES)
	#define U_TYPES

	#define uint unsigned int
	#define uchar unsigned char
	#define ulong unsigned long int
#endif
